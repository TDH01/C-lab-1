 /**\file ghc.c
 *\ author DinhHoaTran
 *\ date 14-03-2020
 */

//DinhHoaTran-n01354661
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ghcontrol.h"


/**\brief Entry point function, first to be called.
 *
 * \param void
 * \return int
 * \author DinhHoaTran
 * \date 14-03-2020
 */
int main(int argc, char* argv[]) {

  struct readings creadings = {0.0};
  struct controls ctrl = {0};
  struct setpoints sets = {0};
    int logged = 0;
   GhControllerInit();
 
  sets = GhSetTarget();

  while(1){
   
    creadings = GhGetReadings();

    logged = GhLogData(argv[1], creadings);
     
    ctrl=GhSetControls(sets,creadings);
    GhDisplayReadings(creadings);
    GhDisplaySetpoints(sets);
    GhDisplayControls(ctrl);
    GhDelay(GHUPDATE);
  }

  return 1;
}
