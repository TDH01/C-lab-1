//DinhHoaTran-n01354661
#ifndef GHCONTROL_H
#define GHCONTROL_H
#define SENSEHAT   1	

// Includes
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <wiringPi.h>

// Constants
#define SENSORS     4
#define LIGHT       3
#define PRESSURE    2
#define HUMIDITY    1
#define TEMPERATURE 0
// new set of constants

// #define SIMULATE 1
#define USTEMP 50
#define LSTEMP -10
#define USHUMID 100
#define LSHUMID 0
#define USPRESS 1016
#define LSPRESS 985

// set thresholds for heater and Humidifier
#define STEMP 20.0
#define SHUMID 45.0
#define SLIGHT 255.0

//set ON OFF
#define ON 1
#define OFF 0
#define GHUPDATE 2000

// Sensehat Constants
#define SENSEHAT 1
#define NUMBARS 8
#define NUMPTS 8.0
#define TBAR 7
#define HBAR 5
#define PBAR 3


typedef struct readings
{
time_t rtime;
double temperature;
double humidity;
double pressure;
double light;
}reading_s;

typedef struct setpoints
{
double temperature;
double humidity;
double light;
} setpoint_s;

typedef struct controls
{
int heater;
int humidifier;
} control_s;

// function prototype
///\cond INTERNAL
void GhControllerInit(void);
void GhDelay(int milliseconds);
void GhDisplayControls(struct controls ctrl);
void GhDisplayHeader(const char * sname);
void GhDisplayReadings(struct readings rdata);
void GhDisplayTargets(struct setpoints spts);
double GhGetHumidity(void);
double GhGetTemperature(void);
int GhGetRandom(int range);
struct readings GhGetReadings(void);
double GhGetPressure(void);
struct controls GhSetControls(struct setpoints target, struct readings rdata);
struct setpoints GhSetTarget();
int GhLogData(char * fname, struct readings ghdata);
struct setpoints GhRetrieveSetpoints(char * fname);
int GhSaveSetpoints(char * fname, struct setpoints spts);
void GhDisplayAll(struct readings rd, struct setpoints sd);
///\endcond

#endif
