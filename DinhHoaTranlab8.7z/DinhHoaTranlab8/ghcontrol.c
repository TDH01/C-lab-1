//DinhHoaTran n01354661

#include <stdlib.h>
#include<stdio.h>
#include <time.h>
#include <string.h>
#include "ghcontrol.h"
#include "pisensehat.h"

void GhControllerInit(void) {
	srand((unsigned) time(NULL));
	GhDisplayHeader("DinhHoaTran n01354661");
		#if SENSEHAT
 			wiringPiSetup();
 			ShInit();
		#endif
	ShClearMatrix();
}

void GhDisplayHeader(const char * sname) {
	fprintf(stdout, "\n%s's Tech153 Greenhouse Controller\n", sname);
}

int GhGetRandom(int range) {
	return rand() % range;
}
void GhDisplayReadings(struct readings rdata) {
	printf("\n%sReadings\t T: %3.1lfC\t H:  %3.1lf%%\tP: %5.1lfmB\tL: %3.0lflux",
    ctime(&rdata.rtime),rdata.temperature,rdata.humidity,
    rdata.pressure,rdata.light);
}

void GhDisplaySetpoints(struct setpoints spts) {
	fprintf(stdout, "\nSetpints\t sT: %3.1lfC\t sH:%3.1lf%%\n", spts.temperature, spts.humidity);
}

void GhDisplayControls(struct controls ctrl){
    char* humid = "OFF";
    char* heat = "OFF";

    if(ctrl.heater == ON) heat = "ON";
    if(ctrl.humidifier == ON) humid = "ON";

    fprintf(stdout, "Controls\t Heater: %2s\t Humidifier: %2s\n", heat, humid);

}



void GhDelay(int milliseconds) {
	long wait;
	clock_t now, start;
	wait = milliseconds *(CLOCKS_PER_SEC/1000);
	start = clock();
	now = start;
	while ((now - start) < wait)
	{
		now = clock();
	}

}

struct readings GhGetReadings(void)
{
  struct readings now = {0};

  now.rtime = time(NULL);
  now.temperature = GhGetTemperature();
  now.humidity = GhGetHumidity();
  now.pressure = GhGetPressure();
  return now;
}


struct controls GhSetControls(struct setpoints target, struct readings rdata)
{
    struct controls cset = {0};
    if (rdata.temperature < target.temperature){
        cset.heater=ON;
    }
    else {
        cset.heater=OFF;
    }
    if (rdata.humidity< target.humidity){
        cset.humidifier=ON;
    }
    else {
        cset.humidifier=OFF;
    }
    return cset;
}



/**\brief Sets Setpoints
 *\ author DinhHoaTran
 *\ date 14-03-2020
 * \param void
 * \return setpoint structure with temperature, humidity, light targets
 */
struct setpoints GhSetSetpoints(){
    struct setpoints spoints;
    spoints = GhRetrieveSetpoints("setpoints.dat");

    if (spoints.temperature == 0) {
        spoints.temperature = STEMP;
        spoints.humidity = SHUMID;
        GhSaveSetpoints("setpoints.dat", spoints);
    }

    return spoints;
}

void GhGetSetpoints(void) {

}

double GhGetTemperature(void) {
#if SIMULATE
	return GhGetRandom(USTEMP-LSTEMP)+LSTEMP;
#else
	ht221sData_s ct = {0};
	ct = ShGetHT221SData();
	return ct.temperature;
#endif
}

double GhGetHumidity(void) {
#if SIMULATE
        return GhGetRandom(USHUMID-LSHUMID) + LSHUMID;
#else
        ht221sData_s ct = {0};
	ct = ShGetHT221SData();
	return ct.humidity;
#endif

}

double GhGetPressure(void) {

#if SIMULATE
        return GhGetRandom(USPRESS-LSPRESS) + LSPRESS;
#else
        lps25hData_s ct = {0};
	ct = ShGetLPS25HData();
	return ct.pressure;
#endif

}

int GhLogData(char * fname, struct readings ghdata) {
    FILE* fp;
    char ltime[50];


    fp = fopen(fname, "a"); /* should check the result */
    // check whether opening the file was successful
    if(fp == NULL)  {
      printf("Can not open the file %s\n", fname);
      exit(EXIT_FAILURE);
    }

    strncpy(ltime, ctime(&ghdata.rtime), 25);

    ltime[3] = ',';
    ltime[7] = ',';
    ltime[10] = ',';
    ltime[19] = ',';

    fprintf(fp,"\n%.24s,%3.1lf,%3.1lf,%5.1lf,%3.0lf",
    ltime,ghdata.temperature,ghdata.humidity,
    ghdata.pressure,ghdata.light);

    fclose(fp);
    return 0;
}

int GhSaveSetpoints(char * fname, struct setpoints spts) {

    FILE* fp = fopen (fname, "w"); /* should check the result */
    //    check whether opening the file was successful
    if(fp == NULL)  {
      printf("Can not open the file %s\n", fname);
        return 0;
    }
    fwrite(&spts , 1 , sizeof(spts) , fp );
    fclose(fp);
    return 1;
}

struct setpoints GhRetrieveSetpoints(char * fname) {
    struct setpoints spts = {0};
    FILE* fp = fopen (fname, "r"); /* should check the result */
    //    check whether opening the file was successful
    if(fp == NULL)  {
      printf("Can not open the file %s\n", fname);
        return spts;
    }
    fread(&spts , 1 , sizeof(spts) , fp );
    fclose(fp);
    return spts;
}
void GhDisplayAll(struct readings rd, struct setpoints sd)
{

	int rv,sv,avh,avl;
	fbpixel pxc = {0};

	ShClearMatrix();
	//Set Temperature Data bar amd Setpoints pixel
	rv = (8.0 * (((rd.temperature-LSTEMP) / (USTEMP-LSTEMP))+0.05))-1.0;
	sv = (8.0 * (((rd.temperature-LSTEMP) / (USTEMP-LSTEMP))+0.05))-1.0;
	pxc.red = 0x00;
	pxc.green =0xFF;
	pxc.blue =0x00;
	ShSetVerticalBar(TBAR,pxc,rv);
	pxc.red = 0xF0;
	pxc.green =0x0F;
	pxc.blue =0xF0;
	ShSetPixel(TBAR,sv,pxc);
}



